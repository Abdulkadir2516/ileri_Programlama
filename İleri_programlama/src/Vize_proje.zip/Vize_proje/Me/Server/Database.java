

package Vize_proje.Me.Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 * @author abdul
 */
public class Database {
    
    public Connection connection = null;
    public Statement statement = null;
    public ResultSet resultSet = null;
        
    public Database(String veritabanı)
    {
        CreateDatabase(veritabanı);
    }
     
    public void CreateDatabase(String veritabanı)
    {
        try {
            // SQLite JDBC sürücüsünü yükleyin
            Class.forName("org.sqlite.JDBC");

            // Veritabanına bağlanın (varsa, oluşturur)
            connection = DriverManager.getConnection("jdbc:sqlite:" + veritabanı + ".db");

            System.out.println("Veritabanına bağlantı başarılı.");

            // Bir tablo oluşturun (örnek tablo)
            statement = connection.createStatement();
            String createTableSQL = "CREATE TABLE records (id INTEGER PRIMARY KEY AutoIncrement, port TEXT, gönderen TEXT, mesaj TEXT, alıcı TEXT)";
            statement.execute(createTableSQL);

            System.out.println("Tablo oluşturuldu.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Bağlantıyı ve ifadeleri kapatın
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
     
    
    
    
    
    
    
}
